How to import Arsin's library is as follows:

<< from libraryArsein.Arsein import Robot_Rubika >>

An example:

from libraryArsein.Arsein import Robot_Rubika

bot = Robot_Rubika("Your Auth Account")


Made by Team ArianBot

Address of our team's GitHub :

https://github.com/Arseinlibrary/Arsein__library.git