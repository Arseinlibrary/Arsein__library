#Copyright (C) 2022 ArianBOT

version= "4.2.5"
copyright = " Arsein Copyright (C) 2022 arianabasi Team ArianBOT \n\n"
Arian = "ArianBOT"

class chup:
	pchap = print(f"Arsein library version {version}\n{copyright}\n☞ library Arsein: https://github.com/Arseinlibrary/Arsein__library.git\n\nدر حال فعال شدن کمی صبور باشید...\n")
	print(" ")
	print(". . . . . . . . . . . ")

