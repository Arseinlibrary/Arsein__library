#Copyright (C) 2022 ArianBOT

version= "7.2.1"
copyright = " Arsein Copyright (C) 2022 arianabasi Team ArianBOT \n\nکانال ما: \n@arian__bot >"
Arian = "ArianBOT"

class chup:
	pchap = print(f"Arsein library version {version}\n{copyright}\n☞ library : کتابخونه آرسین\n\nدر حال فعال شدن آرین بات...\n")
